import { Handler } from '@netlify/functions';

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const userMessage = body.message || '';

    // Advanced modular fallback parsing for pilgrim specific needs
    let reply = "I can guide you through the process. For official helipad onboarding, make sure your biometric registration is verified via the official portal.";
    
    const query = userMessage.toLowerCase();
    if (query.includes('weight') || query.includes('baggage') || query.includes('luggage')) {
      reply = "Strict baggage limits apply for all operators. Each passenger is restricted to a maximum of 5 kg of luggage. Heavy bags will not be accommodated due to altitude weight thresholds.";
    } else if (query.includes('medical') || query.includes('fitness') || query.includes('health')) {
      reply = "Pilgrims ascending to high altitudes like Kedarnath (11,755 ft) must obtain a certified fitness clearance form. Ensure you pack necessary oxygen canisters and warm tracking clothes.";
    } else if (query.includes('ticket') || query.includes('booking') || query.includes('slot')) {
      reply = "Helicopter ticket bookings are officially routed exclusively via the IRCTC HeliYatra ticket platform. Avoid unverified third parties to safeguard against fraudulent slots.";
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reply }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to process conversation stream' }),
    };
  }
};