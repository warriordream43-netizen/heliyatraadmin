-- Schema supporting AI-generated travel itineraries
CREATE TABLE IF NOT EXISTS public.trip_guides (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users ON DELETE CASCADE,
    destination TEXT NOT NULL,
    duration_days INT NOT NULL,
    itinerary JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);