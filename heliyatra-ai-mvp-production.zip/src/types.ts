export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface TripGuide {
  id: string;
  destination: string;
  duration_days: number;
  itinerary: any;
  created_at: string;
}