import React, { useState } from 'react';
import TripGuideChat from './TripGuideChat.tsx';
import { Compass, Shield, CheckCircle, FileText } from 'lucide-react';

export default function App() {
  const [started, setStarted] = useState(false);

  if (started) {
    return <TripGuideChat onBack={() => setStarted(false)} />;
  }

  return (
    <div class="min-h-screen bg-gradient-to-b from-orange-50 to-white text-slate-800 flex flex-col justify-between">
      {/* Hero Section */}
      <div class="max-w-4xl mx-auto px-6 py-12 md:py-20 text-center flex-1 flex flex-col justify-center items-center">
        <div class="w-20 h-20 bg-orange-600 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-orange-200 mb-6">
          <Compass size={44} class="animate-pulse" />
        </div>
        <h1 class="text-4xl md:text-5xl font-black text-slate-900 tracking-tight mb-4">
          HeliYatra <span class="text-orange-600">AI Concierge</span>
        </h1>
        <p class="text-lg text-slate-600 max-w-xl mx-auto mb-8 leading-relaxed">
          Your intelligent copilot for effortless helicopter pilgrimage planning to Kedarnath, Badrinath, and the holy Char Dham shrines.
        </p>

        <button 
          onClick={() => setStarted(true)}
          class="bg-orange-600 hover:bg-orange-700 text-white text-lg font-bold px-8 py-4 rounded-2xl shadow-xl shadow-orange-600/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          Launch AI Assistant
        </button>

        {/* Feature Highlights */}
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-3xl w-full text-left">
          <div class="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
            <Shield class="text-orange-600 mb-3" size={24} />
            <h3 class="font-bold text-slate-900 mb-1">Baggage & Medical Rules</h3>
            <p class="text-sm text-slate-500">Instant tracking of absolute weight guidelines and mandatory health regulations.</p>
          </div>
          <div class="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
            <CheckCircle class="text-orange-600 mb-3" size={24} />
            <h3 class="font-bold text-slate-900 mb-1">Slot & Ticket Tips</h3>
            <p class="text-sm text-slate-500">Expert strategies to streamline official IRCTC ticketing verification steps.</p>
          </div>
          <div class="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
            <FileText class="text-orange-600 mb-3" size={24} />
            <h3 class="font-bold text-slate-900 mb-1">PDF Export ready</h3>
            <p class="text-sm text-slate-500">Compile customized schedules and packing lists into a responsive offline itinerary.</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer class="py-6 border-t border-slate-100 text-center text-xs text-slate-400">
        © 2026 HeliYatra AI Assistant MVP. Ready for deployment on GitHub and Netlify.
      </footer>
    </div>
  );
}