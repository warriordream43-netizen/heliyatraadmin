import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Compass, Calendar, AlertTriangle, Download, ArrowLeft } from 'lucide-react';

interface TripGuideChatProps {
  onBack: () => void;
}

export default function TripGuideChat({ onBack }: TripGuideChatProps) {
  const [messages, setMessages] = useState([
    {
      id: '1',
      role: 'assistant',
      content: 'Namaste! Welcome to HeliYatra AI Assistant. I can help you plan your helicopter pilgrimage to Kedarnath, Badrinath, Gangotri, and Yamunotri. Ask me about booking tips, medical guidelines, baggage limits, or current weather conditions!'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = { id: Date.now().toString(), role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/.netlify/functions/trip-guide-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input, history: messages }),
      });
      const data = await response.json();
      
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || "I'm processing your request. For high-altitude Char Dham yatras, remember to complete your medical fitness check up before onboarding."
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "Connecting to serverless node... Meanwhile, please note that standard helicopter baggage limits are strictly 5 kg per passenger."
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div class="flex flex-col h-screen max-w-4xl mx-auto bg-white shadow-xl">
      {/* Header */}
      <div class="flex items-center justify-between px-6 py-4 bg-orange-600 text-white shadow-md">
        <div class="flex items-center gap-3">
          <button onClick={onBack} class="p-1 hover:bg-orange-700 rounded-full transition-colors">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 class="font-bold text-xl flex items-center gap-2">
              <Compass class="animate-spin-slow" /> HeliYatra AI Guide
            </h1>
            <p class="text-xs text-orange-100">Kedarnath & Chardham Pilgrimage Companion</p>
          </div>
        </div>
        <button class="flex items-center gap-2 bg-orange-700 hover:bg-orange-800 text-white px-3 py-1.5 rounded-lg text-sm font-medium transition-all">
          <Download size={16} /> PDF Guide
        </button>
      </div>

      {/* Messages */}
      <div class="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
        {messages.map((msg) => (
          <div key={msg.id} class={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}>
            <div class={`w-8 h-8 rounded-full flex items-center justify-center text-white flex-shrink-0 ${msg.role === 'user' ? 'bg-indigo-600' : 'bg-orange-600'}`}>
              {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
            </div>
            <div class={`p-4 rounded-xl shadow-sm leading-relaxed ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none border border-slate-100'}`}>
              {msg.content}
            </div>
          </div>
        ))}
        {loading && (
          <div class="flex gap-3 max-w-[85%]">
            <div class="w-8 h-8 rounded-full bg-orange-600 flex items-center justify-center text-white">
              <Bot size={16} />
            </div>
            <div class="bg-white p-4 rounded-xl rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-2">
              <span class="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
              <span class="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
              <span class="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Form Input */}
      <form onSubmit={handleSend} class="p-4 border-t border-slate-100 bg-white flex gap-2 items-center">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about slots, baggage limits, medical rules..."
          class="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
        />
        <button type="submit" class="bg-orange-600 hover:bg-orange-700 text-white p-2.5 rounded-xl shadow-md transition-all">
          <Send size={20} />
        </button>
      </form>
    </div>
  );
}